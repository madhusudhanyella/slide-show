import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  items: any = [];
  activeCount = 0;
  ngOnInit() {
    this.items = [
      {
        id: 1,
        imageUrl: 'test1'
      },
      {
        id: 2,
        imageUrl: 'test2'
      },
      {
        id: 3,
        imageUrl: 'test3'
      },
      {
        id: 4,
        imageUrl: 'test4'
      },
      {
        id: 5,
        imageUrl: 'test5'
      },
      {
        id: 6,
        imageUrl: 'test6'
      },
      {
        id: 7,
        imageUrl: 'test7'
      },
      {
        id: 8,
        imageUrl: 'test8'
      },
      {
        id: 9,
        imageUrl: 'test9'
      },
      {
        id: 10,
        imageUrl: 'test10'
      }
    ];
    this.activeCount = 5;
  }
}
