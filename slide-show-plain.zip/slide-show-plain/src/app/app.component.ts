import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  items: any = [];
  activeCount = 0;
  ngOnInit() {
    this.items = [
      {
        id: 1,
        imageUrl: 'Item-1'
      },
      {
        id: 2,
        imageUrl: 'Item-2'
      },
      {
        id: 3,
        imageUrl: 'Item-3'
      },
      {
        id: 4,
        imageUrl: 'Item-4'
      },
      {
        id: 5,
        imageUrl: 'Item-5'
      },
      {
        id: 6,
        imageUrl: 'Item-6'
      },
      {
        id: 7,
        imageUrl: 'Item-7'
      },
      {
        id: 8,
        imageUrl: 'Item-8'
      },
      {
        id: 9,
        imageUrl: 'Item-9'
      },
      {
        id: 10,
        imageUrl: 'Item-10'
      }
    ];
    this.activeCount = 5;
  }
}
