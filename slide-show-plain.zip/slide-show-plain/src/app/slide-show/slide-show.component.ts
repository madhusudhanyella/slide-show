import { Component, Input, ViewChild, ElementRef, DoCheck } from '@angular/core';

const margin = 30;

const getActiveItems = (items: any, remainingItemsCountForwards: number, activeCount: number, parentWidth: number) => {
  if (!parentWidth) { return []; }
  const newItems = items.filter((i, index) => index >= remainingItemsCountForwards && index < remainingItemsCountForwards + activeCount);
  const radius = parentWidth / 2;
  return newItems.map((item, index) => {
    const angle = (index / (newItems.length - 1)) * Math.PI;
    const x = (radius * Math.cos(angle - Math.PI)) + radius;
    const y = (radius * Math.sin(angle));
    return {...item, x, y};
  });
};

@Component({
  selector: 'app-slide-show',
  templateUrl: './slide-show.component.html',
  styleUrls: ['./slide-show.component.scss']
})
export class SlideShowComponent implements DoCheck {
  @Input() items: any = [];
  @Input() activeCount = 0;

  @ViewChild('self') self: ElementRef;
  @ViewChild('wrapper') wrapper: ElementRef;

  remainingItemsCountForwards = 0;
  activeItems: any = [];
  remainingItemsCountBackwards = 0;

  parentWidth = 0;

  margin = 30;

  innerCircleRadius = 0;

  ngDoCheck() {
    if (!this.parentWidth) {
      const parentWidth = this.self.nativeElement.offsetWidth - (2 * margin);
      this.innerCircleRadius = parentWidth * 0.05;
      this.parentWidth = parentWidth - (2 * this.innerCircleRadius);
      this.activeItems = getActiveItems(this.items, this.remainingItemsCountForwards, this.activeCount, this.parentWidth);
      this.remainingItemsCountBackwards = this.items.length - this.activeItems.length;
    }
  }

  dragged(e, movedItem) {
    const itemsWithMiddlePositions = this.activeItems.map((item: any) => {
      return {
        x: item.x + this.innerCircleRadius,
        y: item.y + this.innerCircleRadius
      };
    });
    const firstPosition = {x: itemsWithMiddlePositions[0].x, y: itemsWithMiddlePositions[0].y};
    const lastPosition = {
      x: itemsWithMiddlePositions[itemsWithMiddlePositions.length - 1].x,
      y: itemsWithMiddlePositions[itemsWithMiddlePositions.length - 1].y
    };
    const newX = e.pageX - this.innerCircleRadius - this.wrapper.nativeElement.offsetLeft;
    const newY = e.pageY - this.innerCircleRadius - this.wrapper.nativeElement.offsetTop;
    const oldX = movedItem.x + this.innerCircleRadius;
    const xOldDiff = oldX - firstPosition.x;
    const xNewDiff = newX - firstPosition.x;
    if (newX < firstPosition.x || newX > lastPosition.x || newY < firstPosition.y) { return; }
    if (xNewDiff - xOldDiff > 0 ) {
      this.updateItems('prev');
    } else if (xNewDiff - xOldDiff < 0 ) {
      this.updateItems('next');
    }
  }

  updateItems(key: string) {
    if (key === 'prev') {
      if (this.remainingItemsCountForwards === 0) { return; }
      this.remainingItemsCountForwards--;
      this.remainingItemsCountBackwards++;
    } else if (key === 'next') {
      if (this.remainingItemsCountBackwards === 0) { return; }
      this.remainingItemsCountBackwards--;
      this.remainingItemsCountForwards++;
    }
    this.activeItems = getActiveItems(this.items, this.remainingItemsCountForwards, this.activeCount, this.parentWidth);
  }

}
