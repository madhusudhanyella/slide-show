import { Component, Input, OnInit, ViewChild, ElementRef, DoCheck } from '@angular/core';

const margin = 30;

const getActiveItems = (items: any, remainingItemsCountForwards: number, activeCount: number, parentWidth: number) => {
  if (!parentWidth) { return []; }
  const newItems = items.filter((i, index) => index >= remainingItemsCountForwards && index < remainingItemsCountForwards + activeCount);
  const radius = parentWidth / 2;
  return newItems.map((item, index) => {
    const angle = (index / (newItems.length - 1)) * Math.PI;
    const x = (radius * Math.cos(angle - Math.PI)) + radius;
    const y = (radius * Math.sin(angle));
    return {...item, x, y};
  });
};

@Component({
  selector: 'app-slide-show',
  templateUrl: './slide-show.component.html',
  styleUrls: ['./slide-show.component.scss']
})
export class SlideShowComponent implements OnInit, DoCheck {
  @Input() items: any = [];
  @Input() activeCount = 0;

  @ViewChild('self') self: ElementRef;

  remainingItemsCountForwards = 0;
  activeItems: any = [];
  remainingItemsCountBackwards = 0;

  parentWidth = 0;

  margin = 30;

  innerCircleRadius = 0;

  ngOnInit() {
    
  }

  ngDoCheck() {
    if (!this.parentWidth) {
      let parentWidth = this.self.nativeElement.offsetWidth - (2 * margin);
      this.innerCircleRadius = parentWidth * 0.05;
      this.parentWidth = parentWidth - (2 * this.innerCircleRadius);
      this.activeItems = getActiveItems(this.items, this.remainingItemsCountForwards, this.activeCount, this.parentWidth);
      this.remainingItemsCountBackwards = this.items.length - this.activeItems.length;
    }
  }

  updateItems(key: string) {
    if (key === 'prev') {
      if (this.remainingItemsCountForwards === 0) { return; }
      this.remainingItemsCountForwards--;
      this.remainingItemsCountBackwards++;
    } else if (key === 'next') {
      if (this.remainingItemsCountBackwards === 0) { return; }
      this.remainingItemsCountBackwards--;
      this.remainingItemsCountForwards++;
    }
    this.activeItems = getActiveItems(this.items, this.remainingItemsCountForwards, this.activeCount, this.parentWidth);
  }

}
